# -*- coding: utf-8 -*-

from . import models
from . import delivery_department
from . import stock_picking
from . import sale_order
from . import res_partner
