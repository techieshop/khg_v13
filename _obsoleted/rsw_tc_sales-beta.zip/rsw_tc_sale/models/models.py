from odoo import models, fields, api


class TCSales(models.Model):
    _name = 'tc.sale'
    _description = 'TC Sales'