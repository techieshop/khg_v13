{
    'name': 'Company customization',
    'description': 'Show company dropdown in single company mode',
    'summary': 'Company customization',
    'version': '1.0.0',
    'depends': ['web'],
    'data': [],
    'installable': True,
    'application': False,
    'auto_install': False
}