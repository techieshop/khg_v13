# -*- coding: utf-8 -*-

from odoo import models, fields, api



class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'
    def format_number(self, number):
        return '{:,.2f}'.format(number)
    def print_summery(self):
        active_ids = self.env.context.get("active_ids", [])
        if active_ids:
            currency=self.env['res.currency'].search([('name','=','HKD')],limit=1)
            second_currecy=False
            orders=self.env['purchase.order'].search([('id','in',active_ids)])
            order_data={}
            total_purchase=0
            total_purchase_converted=0
            total_sale=0
            total_profit=0
            total_margin=0
            for o in orders:
                converted_total=round(( o.amount_total / o.currency_id.rate) * currency.rate,2)
                sale_name=''
                sale_total=0
                sale_profit=0
                sale_margin=0
                if o.sale_order_id:
                    sale_name=o.sale_order_id.name
                    sale_total=o.sale_order_id.amount_total
                    sale_profit=round(o.sale_order_id.amount_total - converted_total,2)
                    sale_margin=round((o.sale_order_id.amount_total - converted_total )/ converted_total,2)
                total_purchase+=o.amount_total
                total_purchase_converted+=converted_total
                total_sale+=sale_total
                total_profit+=sale_profit
                total_margin+=sale_margin
                second_currecy=o.currency_id.symbol
                order_data[o.id]={
                    'name':o.name,
                    'partner':o.partner_id.name,
                    'amount_total':str(self.format_number(o.amount_total))+o.currency_id.symbol,
                    'amount_total_2':str(self.format_number(converted_total))+currency.symbol,
                    'sale_name':sale_name,
                    'sale_total':str(self.format_number(sale_total))+currency.symbol,
                    'sale_profit':str(self.format_number(sale_profit))+currency.symbol,
                    'sale_margin':str(sale_margin)+'%',
                }
            total_purchase=round(total_purchase,2)
            total_purchase_converted=round(total_purchase_converted,2)
            total_sale=round(total_sale,2)
            total_profit=round(total_profit,2)
            total_margin=round(total_margin,2)
            data={
                'orders':order_data,
                'total_purchase':str(self.format_number(total_purchase))+second_currecy,
                'total_purchase_converted':str(self.format_number(total_purchase_converted))+currency.symbol,
                'total_sale':str(self.format_number(total_sale))+currency.symbol,
                'total_profit':str(self.format_number(total_profit))+currency.symbol,
                'total_margin':str(total_margin)+"%"
            }
            if data:
                report = self.env.ref('rsw_shipment_report.action_report_purchase_summary').report_action(self, data=data)
                return report